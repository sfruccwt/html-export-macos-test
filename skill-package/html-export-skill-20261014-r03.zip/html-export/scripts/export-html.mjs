import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

function options(argv){
 const out={};for(let i=0;i<argv.length;i++){const k=argv[i];if(k==='--transparent'||k==='--help'){out[k.slice(2)]=true;continue}if(!k.startsWith('--')||!argv[i+1]||argv[i+1].startsWith('--'))throw Error('Expected --option value: '+k);out[k.slice(2)]=argv[++i]}return out;
}
const args=options(process.argv.slice(2));
if(args.help){console.log('node export-html.mjs --input FILE --out-dir DIR [--formats png,jpg] [--selector CSS] [--scale 2] [--transparent] [--jpeg-background #ffffff] [--jpeg-quality 0.95] [--browser chrome|chromium] [--playwright /path/index.mjs] [--runtime-config FILE]');process.exit(0)}
if(!args.input||!args['out-dir'])throw Error('--input and --out-dir are required');
const input=path.resolve(args.input),outDir=path.resolve(args['out-dir']);fs.accessSync(input,fs.constants.R_OK);
const cfg=args['runtime-config']?JSON.parse(fs.readFileSync(path.resolve(args['runtime-config']),'utf8')):{};
const formats=(args.formats??'png,jpg').split(',').map(v=>v==='jpeg'?'jpg':v);
if(formats.some(f=>!['png','jpg'].includes(f)))throw Error('Formats must be png or jpg');
const scale=Number(args.scale??2),quality=Number(args['jpeg-quality']??0.95),width=Number(args['viewport-width']??1280),height=Number(args['viewport-height']??900),timeout=Number(args['timeout-ms']??30000);
if(![scale,width,height,timeout].every(v=>Number.isFinite(v)&&v>0)||!Number.isFinite(quality)||quality<0||quality>1)throw Error('Invalid numeric option');
const stem=args.name??path.parse(input).name,receiptPath=path.join(outDir,stem+'-export-receipt.json');
const outputs=formats.map(f=>path.join(outDir,stem+'.'+f));
if([...outputs,receiptPath].some(p=>fs.existsSync(p)))throw Error('Output already exists; choose a new output directory or --name');
fs.mkdirSync(outDir,{recursive:true});
const report={status:'running',startedUtc:new Date().toISOString(),input,selector:args.selector??null,formats,scale,viewport:{width,height},jpeg:{background:args['jpeg-background']??'#ffffff',quality},transparentPNG:Boolean(args.transparent),route:'HTML browser render -> screenshot -> PNG/JPEG; no PDF used',files:[],resourceFailures:[]};
let browser,stage='load_playwright';
try{
 const modulePath=args.playwright??process.env.HTML_EXPORT_PLAYWRIGHT_MODULE??cfg.playwrightModule;
 let pw;if(modulePath){pw=await import(pathToFileURL(path.resolve(modulePath)).href);report.playwrightModule=path.resolve(modulePath)}else{try{pw=await import('playwright')}catch{throw Error('Playwright not found. Supply --playwright or --runtime-config with the existing index.mjs; this script does not install dependencies.')}}
 stage='launch_browser';const channel=args.browser??cfg.browser??'chrome';browser=await pw.chromium.launch({headless:true,...(channel==='chromium'?{}:{channel})});report.browserVersion=browser.version();report.nodeVersion=process.version;
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:scale});page.setDefaultTimeout(timeout);
 page.on('requestfailed',r=>{let location;try{const u=new URL(r.url());location=u.protocol==='data:'?'<embedded>':u.origin+u.pathname}catch{location='<resource>'}report.resourceFailures.push({location,error:r.failure()?.errorText})});
 stage='navigate';await page.goto(pathToFileURL(input).href,{waitUntil:'load',timeout});
 stage='font_ready';await page.waitForFunction(()=>!document.fonts||document.fonts.status==='loaded',null,{timeout});await page.evaluate(()=>document.fonts.ready);
 stage='element_ready';const target=args.selector?page.locator(args.selector):page.locator('body');await target.waitFor({state:'visible',timeout});if(args.selector&&await target.count()!==1)throw Error('Selector must identify exactly one visible element');
 stage='image_ready';await target.evaluate(root=>{for(const img of (root instanceof HTMLImageElement?[root]:root.querySelectorAll('img')))img.loading='eager'});
 await page.waitForFunction(selector=>{const root=selector?document.querySelector(selector):document.body;return root&&[...(root instanceof HTMLImageElement?[root]:root.querySelectorAll('img'))].every(i=>i.complete)},args.selector??null,{timeout});
 report.images=await target.evaluate(async root=>{const images=[...(root instanceof HTMLImageElement?[root]:root.querySelectorAll('img'))];for(const i of images){if(!i.naturalWidth)throw Error('An image failed to load; check local paths/network access');await i.decode()}return images.map(i=>({embedded:i.currentSrc.startsWith('data:'),width:i.naturalWidth,height:i.naturalHeight}))});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 report.targetCSS=args.selector?await target.boundingBox():await page.evaluate(()=>({x:0,y:0,width:Math.max(document.documentElement.scrollWidth,innerWidth),height:Math.max(document.documentElement.scrollHeight,innerHeight)}));
 const capture=omitBackground=>args.selector?target.screenshot({type:'png',omitBackground,scale:'device',animations:'disabled',timeout}):page.screenshot({type:'png',fullPage:true,omitBackground,scale:'device',animations:'disabled',timeout});
 let alphaBuffer;
 if(formats.includes('png')){stage='capture_png';const png=await capture(Boolean(args.transparent));if(args.transparent)alphaBuffer=png;const file=path.join(outDir,stem+'.png');fs.writeFileSync(file,png);report.files.push({format:'png',path:file,bytes:png.length,width:png.readUInt32BE(16),height:png.readUInt32BE(20),signature:'PNG'});}
 if(formats.includes('jpg')){
  stage='capture_for_jpeg';alphaBuffer??=await capture(true);stage='encode_jpeg';
  const image=await page.evaluate(async({encoded,background,quality})=>{if(!CSS.supports('color',background))throw Error('Invalid JPEG background color');const img=new Image();img.src='data:image/png;base64,'+encoded;await img.decode();const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const context=canvas.getContext('2d');context.fillStyle=background;context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(img,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',quality));if(!blob)throw Error('JPEG encoding returned no image');const buffer=await blob.arrayBuffer();let binary='';const bytes=new Uint8Array(buffer);for(let n=0;n<bytes.length;n+=16384)binary+=String.fromCharCode(...bytes.subarray(n,n+16384));return{base64:btoa(binary),width:canvas.width,height:canvas.height};},{encoded:alphaBuffer.toString('base64'),background:report.jpeg.background,quality});
  const jpg=Buffer.from(image.base64,'base64'),file=path.join(outDir,stem+'.jpg');fs.writeFileSync(file,jpg);report.files.push({format:'jpg',path:file,bytes:jpg.length,width:image.width,height:image.height,signature:'JPEG'});
 }
 report.status='completed';
}catch(e){report.status='failed';report.failure={stage,message:e.message};process.exitCode=1;}
finally{if(browser)await browser.close();report.finishedUtc=new Date().toISOString();fs.writeFileSync(receiptPath,JSON.stringify(report,null,2));console.log(JSON.stringify(report));}
