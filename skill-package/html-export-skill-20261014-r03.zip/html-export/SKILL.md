---
name: html-export
description: "将已有 HTML 作品导出为可用 PNG/JPG 图片，适用于海报、图表、网页主体或整页；根据 Agent 的实际工具选择可靠渲染路线。"
---

# HTML 作品转图片

目标是用户说“把已有作品转成PNG/JPG”后得到实际图片。优先使用已有真实浏览器截图；SVG/Canvas或PDF中转也可按环境使用。保持原 HTML，导出图片不会继续保留可编辑文字层。本包脚本采用浏览器直接截图与JPEG编码。

## 选择输入与范围

- 用户说“把你生成的作品转成图片”时，先识别当前任务真正的源文件；可能是HTML而不是已有图片。优先当前任务明确的作品，多个候选无法判断时再询问，不重新生图代替导出。
- 用户指定当前浏览器画面时，优先复用已授权的浏览器会话截图。文件脚本只能加载已保存 HTML，不能替代尚未保存的编辑状态。
- 导出已保存本地 HTML 时，先尝试本包的 `scripts/export-html.mjs`。没有适用浏览器能力时，可选择已有受支持的SVG/Canvas或PDF转换工具，以实际图片结果验收。
- 有海报主体与编辑控件时，先确定主体选择器；例如 `--selector "#poster"`。未指定选择器时截整页。
- 先复用已装 Node、Playwright 与浏览器。依赖缺失时报告缺项，安装须沿用户授权；脚本不会自动安装、复制登录态或关闭浏览器安全检查。
- Windows 与 macOS 使用同一脚本。依赖定位、浏览器选择和 macOS 调用见 [平台说明](references/platforms.md)；把路径换成本机真实绝对路径，不沿用其它电脑的运行配置。

## 选择输出格式

格式由用户在当前 Agent 对话中指定，无需修改脚本或打开额外设置页面：“只要 PNG”“只要 JPG”或“两种都要”分别对应 `--formats png`、`--formats jpg`、`--formats png,jpg`。未指定时默认两种各一份。

- PNG：适合文字、图表及需要透明区域的作品；保留透明时加 `--transparent`。该选项保留页面原有透明区域，不会去除元素已经绘制的背景色。
- JPG：适合照片或优先减小体积的分享图；有损压缩、不支持透明。默认白底、质量 0.95，可按用户要求调整。
- 格式、像素倍率和截取范围分别处理。用户说“JPG 两倍像素、只要海报主体”时，同时设置格式、倍率和主体选择器。

给用户的安装、格式选择与对话示例见 [使用说明](references/usage.md)。

## 调用

```powershell
node "<skill目录>/scripts/export-html.mjs" --input "<HTML绝对路径>" --out-dir "<新的输出目录>" --formats png,jpg --selector "#poster" --scale 2 --browser chrome --playwright "<现有playwright/index.mjs绝对路径>" --transparent --jpeg-background "#ffffff" --jpeg-quality 0.95
```

如果 `playwright` 可直接从 Node 导入，可省略 `--playwright`。也可通过环境变量 `HTML_EXPORT_PLAYWRIGHT_MODULE` 或 `--runtime-config` 指定已有模块和浏览器；运行配置格式为 `{"playwrightModule":"<index.mjs路径>","browser":"chrome"}`，本机路径不属于可分享包。

- `--formats`：`png`、`jpg` 或两者。
- `--scale`：图片的像素倍率，默认 2；不是 CSS 字号缩放。
- `--viewport-width/height`：CSS 视口尺寸，默认 1280×900；影响响应式布局。
- `--transparent`：PNG 保留页面透明区域。JPG 不支持透明，先按 `--jpeg-background` 铺底再编码。
- `--jpeg-quality`：0 到 1，默认 0.95。
- `--timeout-ms`：导航和资源准备超时，默认 30000。
- 输出名沿输入文件名；已有同名输出时停止，使用新目录或新名称保存，避免覆盖。
- 输入可编辑 HTML 若依赖外部图片/字体，渲染可能联网。脚本等字体与主体图片完成加载；缺失图片或浏览器错误会出诊断回执，不用模糊成格式不支持。

## 检查交付

打开导出的 PNG/JPG，检查中文字体、完整内容和截取范围。核对签名、实际像素尺寸、JPG 底色；查看 `*-export-receipt.json` 的浏览器版本、输入、范围、倍率与失败阶段。长图受浏览器尺寸/内存约束，截断时按实际原因调整范围、分段或更换可用路线。

提高倍率可改善文字和矢量部分，不会补出位图背景原本没有的细节。接入另一款 Agent 时，须实际调用并得到图像文件；能识别 `SKILL.md` 不等于执行兼容已通过。

