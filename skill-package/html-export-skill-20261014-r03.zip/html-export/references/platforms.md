# Windows / macOS 使用说明

两种系统使用同一个 `scripts/export-html.mjs`。脚本依赖 Node.js、Playwright Library 与 Chrome/Chromium；使用 Node 的 `path` 和 `pathToFileURL` 处理文件，不包含 PowerShell、Windows 注册表或固定的电脑路径。输入 HTML、输出目录和模块位置均由参数指定。静态可移植不等于 macOS 已实机通过。

## 先复用现有依赖

1. 在 Agent 当前执行环境检查 `node --version` 和 `npm --version`；图形应用中的 PATH 可能与终端不同，必要时使用已确认的 Node 绝对路径。
2. 从当前项目或现有依赖目录定位 `playwright/index.mjs`。脚本的 `import('playwright')` 从脚本所在目录向上查找，单纯改变当前工作目录不会保证发现任意项目的模块；模块不在该层级时传 `--playwright` 的实际绝对路径。
3. `--browser chrome` 通过 Playwright 的 Chrome channel 使用其识别的现有系统 Chrome，不硬编码 `.app` 或 `.exe` 路径。找不到 Chrome 时报告 `launch_browser` 错误；不要声称已自动找到。已有 Playwright 配套 Chromium 时用 `--browser chromium`，让 Playwright 按系统及架构选择已安装的浏览器缓存。
4. 配置与模块不能从 Windows 原样搬到 Mac。不要复制 Windows 的 `node.exe`、浏览器缓存、`node_modules` 或带盘符的路径；在目标系统复用或安装对应架构的依赖。

## 依赖确实缺失时

在已有用户安装授权下，先从 [Node.js 官网](https://nodejs.org/en/download) 安装适合目标系统与处理器的受支持版本，保留现有可用安装。Playwright 当前系统要求与版本会变化，按 [官方要求](https://playwright.dev/docs/intro#system-requirements) 核对目标 Mac；2026-10-14 查阅版本列出 macOS 14 及以上，Node 22/24/26 的当前版本。旧系统不要盲装最新依赖。

在一个专用依赖目录内安装 Library，避免更改其它项目：

```sh
cd "<已创建的本任务依赖目录>"
npm install playwright
```

如果已有 Chrome，安装模块后用 `--browser chrome`。只有需要配套 Chromium、且下载仍在用户授权内时，再执行：

```sh
npx playwright install chromium
```

安装命令依据 [Playwright Library](https://playwright.dev/docs/library)。脚本不会自动执行这些命令。下载遇证书/网络或系统安全提示时报告具体错误，不关闭校验或绕过 macOS 安全机制；注册、登录和新协议确认沿用户要求交由本人处理。

## macOS 调用示例

用本机真实路径替换尖括号内容。路径内有空格或中文时保留引号；`~` 不由 Node 脚本展开，使用实际绝对路径，或由 shell 展开的 `$HOME`。

```sh
node "<Skill绝对路径>/scripts/export-html.mjs" --input "<作品绝对路径>/海报.html" --out-dir "<新的输出绝对路径>" --formats png,jpg --selector "#poster" --scale 2 --transparent --jpeg-background "#ffffff" --jpeg-quality 0.95 --browser chrome --playwright "<依赖绝对路径>/node_modules/playwright/index.mjs"
```

已安装配套 Chromium 时仅把浏览器参数改为 `--browser chromium`。选择器取实际 HTML 的主体；没有主体选择器时省略它截整页。使用 macOS 的中文字体，例如源 HTML 可选 `font-family: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif;`。不要为追求 Windows 像素一致而复制或安装未经授权的字体。

## WorkBuddy 本地接入

WorkBuddy 官方说明在代码开发任务中读取项目目录的 `.codebuddy/skills/`，每个 Skill 是含 `SKILL.md` 的独立目录。将本包放到 `<任务项目>/.codebuddy/skills/html-export/` 是本地文件配置方式；仅放置文件不能算 WorkBuddy 已发现或执行成功。使用 WorkBuddy 实际打开该本地项目，确认 Skill 可用，再发自然语言导出请求并核查新生成的图片与回执。

本地路径机制依据 [WorkBuddy 项目配置](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Project)。WorkBuddy 也有 [技能包导入界面](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)；若当前任务禁止外部文件存储，先使用本地项目配置，不将包提交到云端资料库或其它存储。

Mac 的 WorkBuddy 按 [官方 Mac 安装指南](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Installation-Mac-Guide) 选择 Apple 芯片或 Intel 包；不能用 Windows 安装包或以 Linux 测试替代 Mac 实机测试。最终要在真实 Mac 上验收中文、PNG/JPG 签名、像素尺寸、透明/铺底、主体或整页及底部完整性。无真实 Mac 时明确记录未验证，不购买云机或新建远程凭据代替。
