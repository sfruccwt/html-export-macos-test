import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

// Download each native export once and read dimensions from its actual bytes.
export function imageInfo(bytes){
 if(bytes.length>=24&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return{format:'png',width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)};
 if(bytes[0]===255&&bytes[1]===216){
  let offset=2;
  while(offset+3<bytes.length){
   if(bytes[offset++]!==255)throw Error('Invalid JPEG marker');
   while(bytes[offset]===255)offset++;
   const marker=bytes[offset++];
   if(marker===217||marker===218)break;
   if(marker===1||(marker>=208&&marker<=215))continue;
   const length=bytes.readUInt16BE(offset);
   if(length<2||offset+length>bytes.length)throw Error('Incomplete JPEG');
   if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)){
    if(length<7)throw Error('Invalid JPEG frame');
    return{format:'jpg',width:bytes.readUInt16BE(offset+5),height:bytes.readUInt16BE(offset+3)};
   }
   offset+=length;
  }
 }
 throw Error('Export is not a PNG/JPEG image; keep the design and report the returned format');
}

async function main(){
 const args={};for(let i=2;i<process.argv.length;i+=2){if(!process.argv[i]?.startsWith('--')||!process.argv[i+1])throw Error('Expected --option value');args[process.argv[i].slice(2)]=process.argv[i+1]}
 if(!args['out-dir'])throw Error('--out-dir is required');
 const formats=['png','jpg'].filter(f=>args[f+'-url']);if(!formats.length)throw Error('Provide --png-url and/or --jpg-url from actual Ardot export results');
 const dir=path.resolve(args['out-dir']),name=args.name??'ardot';
 const targets=formats.map(format=>({format,file:path.join(dir,name+'.'+format),url:args[format+'-url']}));
 const receipt=path.join(dir,name+'-native-receipt.json');
 if([...targets.map(t=>t.file),receipt].some(file=>fs.existsSync(file)))throw Error('Output exists; choose a new --name or directory');
 const startedUtc=new Date().toISOString();
 const downloads=await Promise.all(targets.map(async target=>{
  const response=await fetch(target.url,{signal:AbortSignal.timeout(30000)});
  if(!response.ok)throw Error('Download HTTP '+response.status+' for '+target.format);
  const bytes=Buffer.from(await response.arrayBuffer()),info=imageInfo(bytes);
  if(info.format!==target.format)throw Error('Requested '+target.format+' but received '+info.format);
  if(!info.width||!info.height)throw Error('Empty image dimensions');
  return{...target,...info,bytes};
 }));
 fs.mkdirSync(dir,{recursive:true});
 const files=downloads.map(({file,format,width,height,bytes})=>{fs.writeFileSync(file,bytes,{flag:'wx'});return{path:file,format,width,height,bytes:bytes.length}});
 const result={status:'completed',route:'Ardot native export',startedUtc,finishedUtc:new Date().toISOString(),files};
 fs.writeFileSync(receipt,JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 main().catch(error=>{console.error(JSON.stringify({status:'failed',message:error.message}));process.exitCode=1});
}
