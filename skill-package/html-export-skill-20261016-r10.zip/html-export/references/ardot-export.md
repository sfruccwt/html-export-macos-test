# Ardot 设计直接导出 · r09

适用于已有Ardot设计转PNG/JPG。保留设计源文件，不把编辑器网页转换为HTML，不重建相似作品。

1. 打开用户提供的真实设计链接一次。新创建的设计可复用创建回执。若打开/创建回执已有画板名称、类型、ID、尺寸，直接使用；否则调用 `fetch_editor_state` 一次，只有回执缺少目标信息才浅层 `batch_read` 一次。唯一顶层Frame直接选中；有多个时按用户指定名称/明确目标匹配，仍有歧义才询问。不得预设2:1、尺寸、当前选择或第一个画板。只保留本次已取得的真实设计URL、目标ID、宽高；后续不重新打开或重复读取。
2. 使用Ardot原生 `export_nodes` 导出指定Frame，传真实设计文件URL/ID、用户要求的格式和倍率；不能把示例或占位fileUrl用于真实调用。先采用当前工具的真实参数schema；不得猜参数名。如果工具尚未暴露，定向发现 `ardot export_nodes` 一次，复用返回的工具名称。能批量传格式时一次导出，否则每种格式一次；本机WorkBuddy的工具一次只接受一个格式，PNG与JPEG各调用一次。
3. 下载链接交给下方固定脚本，一次命令完成下载和真实格式/尺寸读取。每个成功格式只导出一次；用户要JPG时工具格式值为 `jpeg`，输出扩展名为 `.jpg`，不得传 `jpg` 再试错。回执已有下载URL就下载，不因缺少尺寸、想验证效果或另存文件名而再次export_nodes。不把 `capture_screenshot` 当正式导出，不追加网页截图或重渲染。
4. 回复仅给图片入口和尺寸，必要时一条实际限制；不附工具流程长表，不追加报告、笔记或记忆写入。用户另行要求诊断时再处理。

## 固定落盘命令

复用已有Node 22+，脚本只用Node内置模块，不需要Playwright或浏览器，不执行环境准备。Windows已有html-export配置时把读取Node路径和执行合并在一个命令中：

```powershell
& ((Get-Content -LiteralPath ($env:LOCALAPPDATA + '/html-export/runtime.json') -Raw | ConvertFrom-Json).nodeExecutable) '<Skill目录>/scripts/save-ardot.mjs' --png-url '<本次PNG回执真实下载URL>' --jpg-url '<本次JPEG回执真实下载URL>' --out-dir '<输出目录>' --name '<文件名>'
```

macOS使用已知Node；路径未知时在同一命令内用 `/usr/bin/plutil -extract nodeExecutable raw -o - "$HOME/Library/Caches/html-export/runtime.json"` 读取本机配置并执行脚本，见[平台部署说明](platforms.md)。不要假定系统Node与缓存Node位于同一路径。只要一种格式就只传该格式URL。脚本并行下载两种格式，识别实际PNG/JPEG、读取宽高、保存图片及一次回执；成功即交付，不再临时写下载/读图脚本，不重复检查依赖或读取脚本源码。没有可用Node时使用客户端已有下载能力，不为原生导出安装Playwright。下载失败只重试同一URL；只有明确URL失效才重新导出对应格式一次。脚本拒绝GIF/HTML冒充PNG/JPG。

## 原生图片失败时的备用路径

原生PNG/JPEG成功就交付，不再导出HTML。原生图片调用失败时，保留实际错误，沿用同一真实设计和Frame：

1. 当前 `export_nodes` schema支持HTML时，以HTML格式导出该Frame一次；若HTML是独立工具，定向发现一次。下载工具返回的真实HTML及其配套资源，保持相对路径；ZIP则解压后使用其中的入口HTML。若返回可直接访问的作品HTML网址，可直接交给本Skill脚本。禁止下载 `/file/...` 编辑器外壳冒充作品HTML。
2. 下载时确认返回的是HTML或包含HTML的ZIP，再复用已有Node/Playwright运行 `export-html.mjs`，沿用用户的PNG/JPG、倍率和目标范围。曾实测format=html返回GIF，不能仅凭扩展名或工具success认定拿到了HTML；这种情况直接进入第3步，不把GIF包装成HTML。只有缺少依赖才准备一次。不手工重绘、从截图猜布局或编写另一个渲染器。HTML导出可能有与原生设计不同的字体或效果；有已知差异须说明，不宣称完全等价。
3. MCP连接不可用或HTML格式不被支持时，若当前有已授权界面操作能力，打开原设计、选择目标Frame，使用原生PNG/JPG导出菜单；也可使用原生HTML导出后执行第2步。界面无法操作则明确告知用户具体的原生导出操作及阻塞原因。登录/权限问题需要用户完成授权，不循环重试同一个不可用连接，不搜索凭据配置，不通过安装渲染依赖解决MCP连接问题。

只有原生图片、真实HTML及可用原生界面均不可行时才报告未完成，并说明缺少什么。保留源设计，不用近似作品替代。不要仅因一次工具发现失败就宣告设计不能导出。

如果当前客户端只有原生导出菜单，可明确告诉用户在设计文件中选目标Frame并导出PNG/JPG；有被授权的界面操作能力时可操作该菜单。不能把这一人工路径称为已经自动测试通过。

Ardot导出不依赖本Skill的Node/Playwright环境。首次连接可能需要用户授权，但已建立连接后不重复配置。

依据：[官方工具列表](https://docs.ardot.tencent.com/ardot-mcp/features.html)、[HTML导出更新](https://docs.ardot.tencent.com/release-notes.html)、[连接方式](https://docs.ardot.tencent.com/ardot-mcp/quick-start.html)。工具显示在列表中不等于调用成功；以真实设计和Frame的导出结果为准。
