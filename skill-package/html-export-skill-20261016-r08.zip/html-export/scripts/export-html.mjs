import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {pathToFileURL} from 'node:url';

function options(argv){
 const out={};for(let i=0;i<argv.length;i++){const k=argv[i];if(k==='--transparent'||k==='--help'){out[k.slice(2)]=true;continue}if(!k.startsWith('--')||!argv[i+1]||argv[i+1].startsWith('--'))throw Error('Expected --option value: '+k);out[k.slice(2)]=argv[++i]}return out;
}
const args=options(process.argv.slice(2));
if(args.help){console.log('node export-html.mjs --input FILE --out-dir DIR [--formats png,jpg] [--selector CSS] [--scale 2] [--transparent] [--jpeg-background #ffffff] [--jpeg-quality 0.95] [--browser chrome|chromium] [--playwright /path/index.mjs] [--runtime-config FILE]');process.exit(0)}
if(!args.input||!args['out-dir'])throw Error('--input and --out-dir are required');
const inputURL=/^https?:\/\//i.test(args.input)?new URL(args.input):null;
if(inputURL?.hostname==='ardot.tencent.com'&&inputURL.pathname.startsWith('/file/')){
 console.log(JSON.stringify({status:'blocked',skillVersion:'r08',failure:{stage:'input_route',code:'ARDOT_DESIGN_ROUTE',message:'Use Ardot native PNG/JPEG export first. If unavailable, export the actual Frame as HTML through the connected tool or authorized native export UI, then pass that HTML to this renderer. The editor URL is not the design HTML.'}}));
 process.exit(2);
}
const input=inputURL?inputURL.href:path.resolve(args.input),outDir=path.resolve(args['out-dir']);if(!inputURL)fs.accessSync(input,fs.constants.R_OK);
const defaultConfig=path.join(process.platform==='darwin'?path.join(os.homedir(),'Library','Caches'):process.env.LOCALAPPDATA||path.join(os.homedir(),'.cache'),'html-export','runtime.json');
const configPath=args['runtime-config']?path.resolve(args['runtime-config']):fs.existsSync(defaultConfig)?defaultConfig:null;
const cfg=configPath?JSON.parse(fs.readFileSync(configPath,'utf8')):{};
if(!process.env.PLAYWRIGHT_BROWSERS_PATH&&cfg.playwrightBrowsersPath)process.env.PLAYWRIGHT_BROWSERS_PATH=cfg.playwrightBrowsersPath;
const formats=(args.formats??'png,jpg').split(',').map(v=>v==='jpeg'?'jpg':v);
if(formats.some(f=>!['png','jpg'].includes(f)))throw Error('Formats must be png or jpg');
const scale=Number(args.scale??2),quality=Number(args['jpeg-quality']??0.95),width=Number(args['viewport-width']??1280),height=Number(args['viewport-height']??900),timeout=Number(args['timeout-ms']??30000);
if(![scale,width,height,timeout].every(v=>Number.isFinite(v)&&v>0)||!Number.isFinite(quality)||quality<0||quality>1)throw Error('Invalid numeric option');
const stem=args.name??(inputURL?(path.posix.parse(inputURL.pathname).name.replace(/[^a-zA-Z0-9_-]/g,'_')||'webpage'):path.parse(input).name),receiptPath=path.join(outDir,stem+'-export-receipt.json');
const outputs=formats.map(f=>path.join(outDir,stem+'.'+f));
if([...outputs,receiptPath].some(p=>fs.existsSync(p)))throw Error('Output already exists; choose a new output directory or --name');
fs.mkdirSync(outDir,{recursive:true});
const report={status:'running',skillVersion:'r08',startedUtc:new Date().toISOString(),input,selector:args.selector??null,formats,scale,viewport:{width,height},jpeg:{background:args['jpeg-background']??'#ffffff',quality},transparentPNG:Boolean(args.transparent),runtimeConfig:configPath,route:'HTML browser render -> screenshot -> PNG/JPEG; no PDF used',files:[],resourceFailures:[]};
let browser,stage='load_playwright';
try{
 const modulePath=args.playwright??process.env.HTML_EXPORT_PLAYWRIGHT_MODULE??cfg.playwrightModule;
 let pw;if(modulePath){pw=await import(pathToFileURL(path.resolve(modulePath)).href);report.playwrightModule=path.resolve(modulePath)}else{try{pw=await import('playwright')}catch{throw Error('Playwright not found. Supply --playwright or --runtime-config with the existing index.mjs; this script does not install dependencies.')}}
 stage='launch_browser';const channel=args.browser??cfg.browser??'chrome';browser=await pw.chromium.launch({headless:true,...(channel==='chromium'?{}:{channel})});report.browserVersion=browser.version();report.nodeVersion=process.version;
 const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:scale});page.setDefaultTimeout(timeout);
 page.on('requestfailed',r=>{let location;try{const u=new URL(r.url());location=u.protocol==='data:'?'<embedded>':u.origin+u.pathname}catch{location='<resource>'}report.resourceFailures.push({location,error:r.failure()?.errorText})});
 stage='navigate';const response=await page.goto(inputURL?input:pathToFileURL(input).href,{waitUntil:'load',timeout});if(response&&response.status()>=400)throw Error('HTTP '+response.status()+' while loading input');report.finalURL=page.url();
 stage='font_ready';await page.waitForFunction(()=>!document.fonts||document.fonts.status==='loaded',null,{timeout});await page.evaluate(()=>document.fonts.ready);
 stage='element_ready';const target=args.selector?page.locator(args.selector):page.locator('body');await target.waitFor({state:'visible',timeout});if(args.selector&&await target.count()!==1)throw Error('Selector must identify exactly one visible element');
 stage='image_ready';await target.evaluate(root=>{for(const img of (root instanceof HTMLImageElement?[root]:root.querySelectorAll('img')))img.loading='eager'});
 await page.waitForFunction(selector=>{const root=selector?document.querySelector(selector):document.body;return root&&[...(root instanceof HTMLImageElement?[root]:root.querySelectorAll('img'))].every(i=>i.complete)},args.selector??null,{timeout});
 report.images=await target.evaluate(async root=>{const images=[...(root instanceof HTMLImageElement?[root]:root.querySelectorAll('img'))];for(const i of images){if(!i.naturalWidth)throw Error('An image failed to load; check local paths/network access');await i.decode()}return images.map(i=>({embedded:i.currentSrc.startsWith('data:'),width:i.naturalWidth,height:i.naturalHeight}))});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 report.targetCSS=args.selector?await target.boundingBox():await page.evaluate(()=>({x:0,y:0,width:Math.max(document.documentElement.scrollWidth,innerWidth),height:Math.max(document.documentElement.scrollHeight,innerHeight)}));
 const capture=omitBackground=>args.selector?target.screenshot({type:'png',omitBackground,scale:'device',animations:'disabled',timeout}):page.screenshot({type:'png',fullPage:true,omitBackground,scale:'device',animations:'disabled',timeout});
 let alphaBuffer;
 if(formats.includes('png')){stage='capture_png';const png=await capture(Boolean(args.transparent));if(args.transparent)alphaBuffer=png;const file=path.join(outDir,stem+'.png');fs.writeFileSync(file,png);report.files.push({format:'png',path:file,bytes:png.length,width:png.readUInt32BE(16),height:png.readUInt32BE(20),signature:'PNG'});}
 if(formats.includes('jpg')){
  stage='capture_for_jpeg';alphaBuffer??=await capture(true);stage='encode_jpeg';
  const image=await page.evaluate(async({encoded,background,quality})=>{if(!CSS.supports('color',background))throw Error('Invalid JPEG background color');const img=new Image();img.src='data:image/png;base64,'+encoded;await img.decode();const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const context=canvas.getContext('2d');context.fillStyle=background;context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(img,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',quality));if(!blob)throw Error('JPEG encoding returned no image');const buffer=await blob.arrayBuffer();let binary='';const bytes=new Uint8Array(buffer);for(let n=0;n<bytes.length;n+=16384)binary+=String.fromCharCode(...bytes.subarray(n,n+16384));return{base64:btoa(binary),width:canvas.width,height:canvas.height};},{encoded:alphaBuffer.toString('base64'),background:report.jpeg.background,quality});
  const jpg=Buffer.from(image.base64,'base64'),file=path.join(outDir,stem+'.jpg');fs.writeFileSync(file,jpg);report.files.push({format:'jpg',path:file,bytes:jpg.length,width:image.width,height:image.height,signature:'JPEG'});
 }
 stage='verify_outputs';
 // Decode saved files in the same browser on Windows and macOS; no extra dependencies.
 const saved=report.files.map(file=>{
  const bytes=fs.readFileSync(file.path);
  const valid=file.format==='png'?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):bytes[0]===255&&bytes[1]===216&&bytes[2]===255&&bytes[bytes.length-2]===255&&bytes[bytes.length-1]===217;
  if(!valid)throw Error('Invalid '+file.format+' file signature');
  return {format:file.format,encoded:bytes.toString('base64'),width:file.width,height:file.height};
 });
 const checks=await page.evaluate(async files=>{
  const result=[];
  for(const file of files){
   const img=new Image();img.src='data:image/'+(file.format==='jpg'?'jpeg':'png')+';base64,'+file.encoded;await img.decode();
   if(img.naturalWidth!==file.width||img.naturalHeight!==file.height)throw Error('Decoded image size differs from captured size');
   const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
   const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0);
   const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;
   let hasTransparentPixels=false;for(let i=3;i<pixels.length;i+=4){if(pixels[i]<255){hasTransparentPixels=true;break}}
   const corners=[0,canvas.width-1,(canvas.height-1)*canvas.width,canvas.width*canvas.height-1].map(i=>Array.from(pixels.slice(i*4,i*4+4)));
   result.push({format:file.format,signatureValid:true,decoded:true,width:canvas.width,height:canvas.height,hasTransparentPixels,cornerRGBA:corners});
  }
  return result;
 },saved);
 const expected={width:report.targetCSS.width*scale,height:report.targetCSS.height*scale};
 for(const check of checks){
  if(Math.abs(check.width-expected.width)>1||Math.abs(check.height-expected.height)>1)throw Error('Output dimensions do not match requested area and scale');
  if(check.format==='jpg'&&check.hasTransparentPixels)throw Error('JPEG must be opaque');
 }
 report.verification={status:'passed',expectedPixels:expected,files:checks,jpegBackgroundApplied:formats.includes('jpg')?report.jpeg.background:null};
 report.notes=[];
 if(args.transparent&&checks.some(c=>c.format==='png'&&!c.hasTransparentPixels))report.notes.push('PNG has no transparent pixels: the HTML may paint an opaque background; --transparent does not remove element backgrounds.');
 if(report.resourceFailures.length)report.notes.push('Some page requests failed; see resourceFailures.');
 report.status='completed';
}catch(e){report.status='failed';report.failure={stage,message:e.message};process.exitCode=1;}
finally{if(browser)await browser.close();report.finishedUtc=new Date().toISOString();fs.writeFileSync(receiptPath,JSON.stringify(report,null,2));console.log(JSON.stringify(report));}
