#!/bin/bash
set -euo pipefail
if [ "$(uname -s)" != Darwin ]; then echo 'This entry point requires macOS.' >&2; exit 1; fi
script_dir="$(cd "$(dirname "$0")" && pwd)"
runtime_dir="$HOME/Library/Caches/html-export"
args=("$@")
for ((i=0;i<${#args[@]};i++)); do
  if [ "${args[$i]}" = --runtime-dir ]; then runtime_dir="${args[$((i+1))]}"; fi
done
mkdir -p "$runtime_dir"
runtime_dir="$(cd "$runtime_dir" && pwd)"
usable_node() {
  [ -x "$1" ] && "$1" -e 'const fs=require("fs"),p=require("path"),d=p.dirname(process.execPath);process.exit(Number(process.versions.node.split(".")[0])>=22&&[p.join(d,"../lib/node_modules/npm/bin/npm-cli.js"),p.join(d,"node_modules/npm/bin/npm-cli.js")].some(x=>fs.existsSync(x))?0:1)' >/dev/null 2>&1
}
node_bin="$(command -v node || true)"
node_action=reused
if ! usable_node "$node_bin"; then node_bin="$runtime_dir/node/bin/node"; fi
if ! usable_node "$node_bin"; then
  case "$(uname -m)" in arm64) arch=arm64;; x86_64) arch=x64;; *) echo 'Unsupported Mac architecture' >&2; exit 1;; esac
  version="$(curl --fail --location --silent --show-error https://nodejs.org/dist/index.tab | awk '$1 ~ /^v24\./ && !found {print $1;found=1}')"
  [ -n "$version" ] || { echo 'Could not locate Node 24 release' >&2; exit 1; }
  archive="$runtime_dir/node-download.tar.gz"
  curl --fail --location --show-error "https://nodejs.org/dist/$version/node-$version-darwin-$arch.tar.gz" --output "$archive"
  mkdir -p "$runtime_dir/node"
  tar -xzf "$archive" -C "$runtime_dir/node" --strip-components=1
  rm "$archive"
  node_action=installed
fi
"$node_bin" -e 'require("fs").writeFileSync(process.argv[1],JSON.stringify({action:process.argv[2],nodeExecutable:process.execPath,version:process.version},null,2))' "$runtime_dir/node-setup.json" "$node_action"
"$node_bin" "$script_dir/prepare-runtime.mjs" --runtime-dir "$runtime_dir" "$@"
