import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const args={};
for(let i=2;i<process.argv.length;i+=2){
  if(!['--runtime-dir','--playwright','--browser'].includes(process.argv[i])||!process.argv[i+1]) throw Error('Expected --runtime-dir DIR, --playwright FILE or --browser chrome|chromium');
  args[process.argv[i].slice(2)]=process.argv[i+1];
}
if(Number(process.versions.node.split('.')[0])<22) throw Error('Node 22 or newer required; on macOS run setup-macos.sh');
if(args.browser&&!['chrome','chromium'].includes(args.browser)) throw Error('Browser must be chrome or chromium');
const base=process.platform==='darwin'?path.join(os.homedir(),'Library','Caches'):process.env.LOCALAPPDATA||path.join(os.homedir(),'.cache');
const dir=path.resolve(args['runtime-dir']||path.join(base,'html-export'));
fs.mkdirSync(dir,{recursive:true});
const configFile=path.join(dir,'runtime.json');
const previous=fs.existsSync(configFile)?JSON.parse(fs.readFileSync(configFile,'utf8')):{};
if(!process.env.PLAYWRIGHT_BROWSERS_PATH&&previous.playwrightBrowsersPath) process.env.PLAYWRIGHT_BROWSERS_PATH=previous.playwrightBrowsersPath;
const receipt={status:'running',startedUtc:new Date().toISOString(),node:process.execPath,nodeVersion:process.version,installed:[],diagnostics:[]};
function run(file,argv){
  const result=spawnSync(file,argv,{stdio:'inherit',env:process.env});
  if(result.error) throw result.error;
  if(result.status!==0) throw Error(`${file} failed (exit ${result.status}): ${argv.join(' ')}`);
}
try{
  const require=createRequire(import.meta.url);
  const candidates=[args.playwright,process.env.HTML_EXPORT_PLAYWRIGHT_MODULE,previous.playwrightModule];
  for(const root of [process.cwd(),path.dirname(fileURLToPath(import.meta.url))]){
    try{candidates.push(require.resolve('playwright',{paths:[root]}));}catch{}
  }
  candidates.push(path.join(dir,'node_modules','playwright','index.mjs'));
  let pw,modulePath;
  for(const candidate of candidates.filter(Boolean)){
    try{
      const loaded=await import(pathToFileURL(path.resolve(candidate)).href);
      if(!loaded.chromium) throw Error('Module does not expose chromium');
      pw=loaded;modulePath=path.resolve(candidate);break;
    }catch(e){receipt.diagnostics.push({candidate,message:e.message});}
  }
  if(!pw){
    const nodeDir=path.dirname(process.execPath);
    const npm=[path.join(nodeDir,'node_modules/npm/bin/npm-cli.js'),path.resolve(nodeDir,'../lib/node_modules/npm/bin/npm-cli.js')].find(p=>fs.existsSync(p));
    if(!npm) throw Error('npm is missing from this Node installation. Use a complete Node distribution (macOS: setup-macos.sh).');
    run(process.execPath,[npm,'install','--prefix',dir,'--no-audit','--no-fund','playwright@1.64.0']);
    receipt.installed.push('playwright');
    modulePath=path.join(dir,'node_modules/playwright/index.mjs');
    pw=await import(pathToFileURL(modulePath).href);
  }
  let browserName,browserVersion;
  for(const name of args.browser?[args.browser]:['chrome','chromium']){
    try{
      const browser=await pw.chromium.launch({headless:true,timeout:15000,...(name==='chrome'?{channel:'chrome'}:{})});
      browserVersion=browser.version();await browser.close();browserName=name;break;
    }catch(e){receipt.diagnostics.push({browser:name,message:e.message});}
  }
  if(!browserName){
    if(args.browser==='chrome') throw Error('Chrome could not launch. Omit --browser to allow managed Chromium installation.');
    const cli=path.join(path.dirname(require.resolve('playwright/package.json',{paths:[path.dirname(modulePath)]})),'cli.js');
    run(process.execPath,[cli,'install','chromium']);
    receipt.installed.push('chromium');
    const browser=await pw.chromium.launch({headless:true,timeout:15000});
    browserVersion=browser.version();await browser.close();browserName='chromium';
  }
  const config={nodeExecutable:process.execPath,playwrightModule:modulePath,browser:browserName,...(process.env.PLAYWRIGHT_BROWSERS_PATH?{playwrightBrowsersPath:process.env.PLAYWRIGHT_BROWSERS_PATH}:{})};
  fs.writeFileSync(configFile,JSON.stringify(config,null,2));
  Object.assign(receipt,{status:'completed',configFile,browserVersion,config});
}catch(e){receipt.status='failed';receipt.error=e.message;process.exitCode=1;}
finally{
  receipt.finishedUtc=new Date().toISOString();
  fs.writeFileSync(path.join(dir,'setup-receipt.json'),JSON.stringify(receipt,null,2));
  console.log(JSON.stringify(receipt,null,2));
}
