# Windows / macOS 依赖与调用

r06日常导出直接复用已有runtime.json，不运行准备脚本。Windows配置读取与导出放在同一次命令调用中，详见SKILL.md。固定检查复用当前渲染浏览器，不需要Python/Pillow。

默认配置位置：Windows `%LOCALAPPDATA%/html-export/runtime.json`；macOS `~/Library/Caches/html-export/runtime.json`。导出脚本自动读取，非默认位置传 `--runtime-config`。直接使用配置中的nodeExecutable；Mac缓存Node路径为 `~/Library/Caches/html-export/node/bin/node`。图形应用找不到PATH中的Node时先使用已知绝对路径，不重新安装。

下面的准备入口只用于首次缺依赖或实际依赖错误，升级Skill无需重装运行环境。

## Mac 自动准备

```sh
bash "<Skill绝对路径>/scripts/setup-macos.sh"
```

先复用 PATH 中可用的 Node 22+ 与 npm，再检查 Skill 缓存的 Node；没有时按当前处理器下载官方 Node 24（Apple 芯片 arm64 / Intel x64）。图形应用 PATH 可能不同；Agent 已定位现有 Node 时，把其 bin 目录加入本次命令 PATH 可避免重复下载。

默认运行目录 `~/Library/Caches/html-export`，可传 `--runtime-dir "<绝对路径>"` 指定。无需 sudo 或 Homebrew，不修改全局 PATH。

## 共同依赖准备

准备脚本检查指定模块、上次配置、当前项目/Skill 可解析的模块，以及 Skill 缓存。已知外部模块传 `--playwright "<playwright/index.mjs绝对路径>"`；不会遍历整台电脑寻找未知依赖。找不到才在独立运行目录安装 Playwright 1.64.0。

先尝试现有 Chrome，再尝试配套 Chromium；都不可用时下载并启动配套 Chromium。已有浏览器只作无头启动检查，不读取日常登录会话。`--browser chromium` 可明确选择配套浏览器；`--browser chrome` 要求现有 Chrome，失败时报错。

成功写出 `runtime.json`（实际路径与浏览器）和 `setup-receipt.json`（安装项、诊断和结果）。Mac 另有 `node-setup.json`。再次运行复用环境；安装项为空表示本次未安装依赖。配置留在目标电脑，不放进分享包。

Windows 已有 Node 22+ 与 npm 时运行：

```powershell
node "<Skill目录>/scripts/prepare-runtime.mjs"
```

Windows 默认目录 `%LOCALAPPDATA%/html-export`。缺 Node 时需 Agent 先定位或安装官方 Node；自动下载 Node 的入口针对 Mac。不要把 Windows 的 Node、node_modules、浏览器缓存或配置搬到 Mac。

## 导出

读取生成的配置，使用其中的 `nodeExecutable`：

```sh
"<nodeExecutable>" "<Skill目录>/scripts/export-html.mjs" --runtime-config "<runtime.json路径>" --input "<作品.html>" --out-dir "<新的输出目录>" --formats png,jpg --selector '#poster' --scale 2 --transparent
```

只要 JPG 用 `--formats jpg`，只要 PNG 用 `--formats png`。未指定选择器时截整页。准备入口不接收导出参数；先准备，再导出。

## 要求与限制

首次补齐依赖需要联网。下载或权限失败时保留具体报错，不关闭证书校验或系统保护。包不捆绑依赖，不要求 Python；测试中的 Pillow 仅用于独立验图。外部图片与字体仍需可访问。

面向 macOS 14+。自动选择 arm64/x64 不等于两个架构都已实测；测试结果见随包交付说明。WorkBuddy Mac 客户端导入、权限与自然语言调用仍待实测。

依据：[Node 官方下载](https://nodejs.org/en/download)、[Playwright Library](https://playwright.dev/docs/library)、[浏览器安装](https://playwright.dev/docs/browsers)。
