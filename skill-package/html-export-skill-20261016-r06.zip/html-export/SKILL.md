---
name: html-export
description: "将已有本地HTML导出PNG/JPG；一次调用完成渲染和固定检查，复用现有环境，直接交付图片。"
---

# HTML 作品转图片 · r06

把用户指定的已有HTML转成真实图片，保留原HTML。Windows/macOS使用同一脚本。

## 固定执行流程

1. 确定输入绝对路径、输出目录、格式、范围。明确给出的路径与选择器直接使用，不重读HTML或脚本验证，不先用Test-Path或目录列表确认存在；执行时的实际错误负责报告缺失。只有无法判断源文件或主体选择器时才做一次针对性读取；多个候选仍有歧义时询问用户。
2. **已有环境直接导出。** 复用用户给的runtime配置或本次任务已知配置/nodeExecutable，不重复运行准备脚本、检查Node版本、列目录或探测浏览器。未给配置时，导出脚本自动读取本机默认缓存的runtime.json。首次没有可用环境，或导出明确报依赖缺失/启动失败，才按[平台说明](references/platforms.md)准备一次。依赖齐备时不下载、不重装。
3. **只调用一次下面的导出命令。** 脚本在同一浏览器中完成字体/图片就绪、保存、签名、解码、尺寸、PNG透明信息与JPG不透明检查，将结果写入回执。退出成功且 `status=completed`、`verification.status=passed` 就完成技术检查。
4. **直接交付图片。** 回复只给PNG/JPG入口、实际尺寸及必要的一条notes提示。可使用客户端展示文件工具一次，不再调用读图/截图工具做二次检查；不追加独立检查、像素采样、哈希/mtime比对、临时脚本、测试报告、笔记/记忆写入或长篇参数说明。用户另行明确要求检查时才处理该项。

失败时按回执failure.stage/message处理实际错误，不能把成功结果重新纳入开放式验证。`verify_outputs`失败只报告具体失败，不临时编写新的验证器。缺依赖可准备后重试一次；已有同名产物使用新目录或 `--name`，不覆盖。

## 调用

Windows PowerShell：用户已给runtime配置时，直接用以下一条命令读取配置并导出。不要先调用读文件工具获取nodeExecutable；不要拆成检查、读配置、执行三个工具回合。

```powershell
$htmlExportConfig = '<已有runtime.json绝对路径>'
& ((Get-Content -LiteralPath $htmlExportConfig -Raw | ConvertFrom-Json).nodeExecutable) '<Skill目录>/scripts/export-html.mjs' --input '<HTML绝对路径>' --out-dir '<新输出目录>' --formats png,jpg --selector '#poster' --scale 2 --transparent --runtime-config $htmlExportConfig
```

未给配置时，Windows默认配置可用 `$env:LOCALAPPDATA + '/html-export/runtime.json'`；已知nodeExecutable则直接调用。macOS已知Node路径或使用自动准备的缓存Node时直接调用；缓存路径为 `$HOME/Library/Caches/html-export/node/bin/node`，默认runtime配置由脚本自动读取，无需预读配置。

通用命令（Node路径已知时）：

```sh
"<nodeExecutable>" "<Skill目录>/scripts/export-html.mjs" --input "<HTML绝对路径>" --out-dir "<新输出目录>" --formats png,jpg --selector "#poster" --scale 2 --transparent --runtime-config "<已有runtime.json>"
```

- 格式：`png`、`jpg`、`png,jpg`；未指定默认两种。只要一种就只传一种。
- 范围：主体用 `--selector`；整页省略。默认视口1280×900，可传 `--viewport-width/height`。
- 倍率：`--scale`默认2，宽高各乘2。
- PNG：`--transparent`保留已有透明区域，不抠除HTML元素背景。回执提示没有透明像素时如实简短说明即可，不修改HTML、不再次检测。
- JPG：默认铺白底、质量0.95；可传 `--jpeg-background`、`--jpeg-quality`（0–1）。非白色角点不意味着铺底失败，角点可能有页面内容。
- `--runtime-config`可省略，自动找默认缓存；也可用 `--playwright`与`--browser chrome|chromium`指定已有依赖。脚本自身不安装依赖。
- 默认资源等待超时30000ms，可传 `--timeout-ms`。

## 固定检查的边界

回执确认文件可解码、尺寸匹配、资源就绪和透明信息，不声称判断设计是否美观、中文语义或所有字形正确。HTML中的外部资源仍需可访问。文字会栅格化，保留HTML用于编辑。当前浏览器未保存的编辑状态应先保存，不能用旧文件代替。

给用户的安装与升级说明见[使用说明](references/usage.md)。

